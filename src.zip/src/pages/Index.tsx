import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import ProfileCard from "@/components/ProfileCard";
import InfoPanel from "@/components/InfoPanel";

const Index = () => {
  const profiles = [
    {
      name: "Sarah Johnson",
      role: "Senior HR Manager",
      experience: "8+ years",
      skills: ["Technical Hiring", "Behavioral Analysis", "Leadership"],
      rating: 4.8,
      price: "₹299/session",
      type: "hr" as const
    },
    {
      name: "Rajesh Kumar",
      role: "Full Stack Developer",
      experience: "6+ years",
      skills: ["React", "Node.js", "System Design"],
      rating: 4.9,
      price: "₹399/session",
      type: "mentor" as const
    },
    {
      name: "Priya Sharma",
      role: "Tech Recruiter",
      experience: "5+ years",
      skills: ["Frontend", "Backend", "DevOps"],
      rating: 4.7,
      price: "₹249/session",
      type: "hr" as const
    },
    {
      name: "Amit Patel",
      role: "Senior Software Engineer",
      experience: "10+ years",
      skills: ["Java", "Microservices", "Cloud"],
      rating: 5.0,
      price: "₹499/session",
      type: "mentor" as const
    },
    {
      name: "Neha Gupta",
      role: "HR Business Partner",
      experience: "7+ years",
      skills: ["Culture Fit", "Communication", "Strategy"],
      rating: 4.6,
      price: "₹329/session",
      type: "hr" as const
    },
    {
      name: "Vikram Singh",
      role: "DevOps Engineer",
      experience: "4+ years",
      skills: ["AWS", "Docker", "Kubernetes"],
      rating: 4.8,
      price: "₹449/session",
      type: "mentor" as const
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      <Navigation />
      
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <h1 className="text-3xl font-display font-bold text-foreground mb-3">Find Your Perfect Interview Coach</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Connect with experienced HRs and industry mentors for personalized mock interviews and career guidance</p>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Left Sidebar */}
          <div className="col-span-3">
            <div className="sticky top-24">
              <Sidebar />
            </div>
          </div>
          
          {/* Main Content */}
          <div className="col-span-6">
            <div className="space-y-6">
              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-card p-4 rounded-lg border border-border text-center hover:shadow-md smooth-transition">
                  <div className="text-2xl font-bold text-primary">150+</div>
                  <div className="text-xs text-muted-foreground font-medium">Active HRs</div>
                </div>
                <div className="bg-card p-4 rounded-lg border border-border text-center hover:shadow-md smooth-transition">
                  <div className="text-2xl font-bold text-accent">200+</div>
                  <div className="text-xs text-muted-foreground font-medium">Mentors</div>
                </div>
                <div className="bg-card p-4 rounded-lg border border-border text-center hover:shadow-md smooth-transition">
                  <div className="text-2xl font-bold text-success">95%</div>
                  <div className="text-xs text-muted-foreground font-medium">Success Rate</div>
                </div>
              </div>
              
              {/* Section Divider */}
              <div className="flex items-center space-x-4 mb-6">
                <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent flex-1"></div>
                <span className="text-sm font-medium text-muted-foreground bg-background px-4">Available Coaches</span>
                <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent flex-1"></div>
              </div>
              
              <div className="grid gap-6">
                {profiles.map((profile, index) => (
                  <ProfileCard key={index} {...profile} />
                ))}
              </div>
            </div>
          </div>
          
          {/* Right Info Panel */}
          <div className="col-span-3">
            <div className="sticky top-24">
              <InfoPanel />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
