import { RegisterForm } from "@/components/RegisterForm";

const Index = () => {
  return <RegisterForm />;
};

export default Index;
